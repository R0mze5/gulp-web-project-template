# Changelog

### 3.0.0 (*2018-10-06*)
- change structure of projects
- add documentation
