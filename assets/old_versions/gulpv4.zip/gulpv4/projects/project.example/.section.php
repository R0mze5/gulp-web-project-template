<?
$sSectionName = "website";
$arDirProperties = array(
   "description" => "website",
   "keywords" => "website",
   "robots" => "index, follow"
);
?>