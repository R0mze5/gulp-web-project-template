'use strict';

global.variables = {
	sourcePath: '/dist/',
};
